The geodatabase or Excel files in this folder contain the prioritized barrier results from the Maine Statewide Aquatic Barrier Prioritization app.  

This material is based upon work supported by the Natural Resources Conservation Service, US Department of Agriculture, under number NR181218XXXXG001.

Prioritized results are included for five diadromous and brook trout scenarios, for the entire state of Maine and stratified by subwatershed.  Column descriptions can be found in the StatewideBarriers_Metadata.xml and the StatewideMetricGlossary.pdf files in this folder.  

These results and important contextual information can be accessed via the web application at http://maps.coastalresilience.org/maine. For additional information, conatct Erik Martin, emartin@tnc.org.